Name: Xi Han (504136747)
              Yige Li (604426464)
1. For PartA, we implemented the Search Interface, including creating HTML page, keywordSearch.html, implementing SearchServlet, and forwarding the results of the query to a JSP page. Implementing the Item Interface, including creating a static HTML page, getItem.html and implementing ItemServlet class. Next, we added Navigational Links.

2. For PartB, we first finished a demo adding Google Maps. Then we developed a Google-Suggest Proxy and Google-Suggest Client. Finally we merged the demos into a page.

Notes: If we click eBaySearch, we will be back to the search page.